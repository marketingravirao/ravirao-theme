<?php
/**
 * Template: Event Title, Mini view.
 *
 * @category Templates
 * @package  My Calendar
 * @author   Joe Dolson
 * @license  GPLv2
 * @link     https://www.joedolson.com/my-calendar/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$title_template = mc_get_template( 'title' );
if ( mc_template_settings( 'title' ) !== $title_template ) {
	// If the title template has been modified, use that.
	echo wp_kses_post( mc_draw_template( $data, $title_template ) );
} else {
	mc_template_tag( $data, 'title' );
}
